<div class="row">
    <?php echo $records->render(); ?>

</div>
