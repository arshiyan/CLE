<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Post Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('post_url', 'Post Url:'); ?>

    <?php echo Form::text('post_url', null, ['class' => 'form-control']); ?>

</div>

<!-- Total Winner Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('total_winner', 'Total Winner:'); ?>

    <?php echo Form::text('total_winner', null, ['class' => 'form-control']); ?>

</div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::select('status', ['Pending' => 'Pending', 'Running' => 'Running', 'Done' => 'Done', 'Expired' => 'Expired'], null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('campains.index'); ?>" class="btn btn-default">Cancel</a>
</div>
